-- VietStylist V2 additive SQLite migration.
-- Review before applying. No destructive DROP/RENAME.

CREATE TABLE IF NOT EXISTS cultural_sources_v2 (
    id TEXT PRIMARY KEY,
    source_type TEXT NOT NULL,
    title TEXT NOT NULL,
    creator TEXT,
    publisher TEXT,
    institution TEXT,
    publication_date TEXT,
    url TEXT,
    language TEXT NOT NULL DEFAULT 'vi',
    accessed_at TEXT NOT NULL,
    trust_tier TEXT NOT NULL DEFAULT 'F_UNVERIFIED',
    rights_json TEXT NOT NULL,
    review_status TEXT NOT NULL DEFAULT 'draft',
    notes TEXT,
    version INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cultural_assertions_v2 (
    id TEXT PRIMARY KEY,
    subject_type TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    predicate TEXT NOT NULL,
    value_json TEXT NOT NULL,
    qualifiers_json TEXT NOT NULL DEFAULT '{}',
    statement_vi TEXT NOT NULL,
    confidence REAL NOT NULL DEFAULT 0.0,
    consensus TEXT NOT NULL DEFAULT 'single_source',
    review_status TEXT NOT NULL DEFAULT 'draft',
    version INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS assertion_evidence_v2 (
    id TEXT PRIMARY KEY,
    assertion_id TEXT NOT NULL REFERENCES cultural_assertions_v2(id) ON DELETE CASCADE,
    source_id TEXT NOT NULL REFERENCES cultural_sources_v2(id) ON DELETE RESTRICT,
    locator TEXT NOT NULL,
    media_binding_ids_json TEXT NOT NULL DEFAULT '[]',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS garment_definitions_v2 (
    id TEXT PRIMARY KEY,
    slug TEXT UNIQUE NOT NULL,
    name_json TEXT NOT NULL,
    aliases_json TEXT NOT NULL DEFAULT '[]',
    category TEXT NOT NULL,
    summary TEXT,
    version INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS garment_variants_v2 (
    id TEXT PRIMARY KEY,
    garment_id TEXT NOT NULL REFERENCES garment_definitions_v2(id) ON DELETE CASCADE,
    name_json TEXT NOT NULL,
    qualifiers_json TEXT NOT NULL DEFAULT '{}',
    version INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'draft'
);

CREATE TABLE IF NOT EXISTS garment_components_v2 (
    id TEXT PRIMARY KEY,
    garment_id TEXT REFERENCES garment_definitions_v2(id) ON DELETE CASCADE,
    garment_variant_id TEXT REFERENCES garment_variants_v2(id) ON DELETE CASCADE,
    component_type TEXT NOT NULL,
    name_json TEXT NOT NULL,
    structural_role TEXT NOT NULL DEFAULT 'optional',
    attributes_json TEXT NOT NULL DEFAULT '{}',
    generation_policy_json TEXT NOT NULL DEFAULT '{}',
    version INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'draft'
);

CREATE TABLE IF NOT EXISTS accessory_definitions_v2 (
    id TEXT PRIMARY KEY,
    slug TEXT UNIQUE NOT NULL,
    name_json TEXT NOT NULL,
    category TEXT NOT NULL,
    attributes_json TEXT NOT NULL DEFAULT '{}',
    version INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'draft'
);

CREATE TABLE IF NOT EXISTS style_options_v2 (
    id TEXT PRIMARY KEY,
    option_type TEXT NOT NULL,
    value_json TEXT NOT NULL,
    historical_status TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft'
);

CREATE TABLE IF NOT EXISTS compatibility_relations_v2 (
    id TEXT PRIMARY KEY,
    subject_type TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    relation TEXT NOT NULL,
    object_type TEXT NOT NULL,
    object_id TEXT NOT NULL,
    qualifiers_json TEXT NOT NULL DEFAULT '{}',
    assertion_ids_json TEXT NOT NULL DEFAULT '[]',
    status TEXT NOT NULL DEFAULT 'draft'
);

CREATE TABLE IF NOT EXISTS cultural_rules_v2 (
    id TEXT PRIMARY KEY,
    category TEXT NOT NULL,
    severity TEXT NOT NULL,
    scope_json TEXT NOT NULL DEFAULT '[]',
    condition_json TEXT NOT NULL,
    action_json TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'draft'
);

CREATE TABLE IF NOT EXISTS cultural_media_bindings_v2 (
    id TEXT PRIMARY KEY,
    media_asset_id TEXT NOT NULL REFERENCES media_assets(id) ON DELETE CASCADE,
    source_id TEXT REFERENCES cultural_sources_v2(id) ON DELETE SET NULL,
    subject_type TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    view_type TEXT NOT NULL,
    quality_json TEXT NOT NULL DEFAULT '{}',
    usage_json TEXT NOT NULL DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS renderable_items_v2 (
    id TEXT PRIMARY KEY,
    canonical_entity_type TEXT NOT NULL,
    canonical_entity_id TEXT NOT NULL,
    canonical_variant_id TEXT,
    slot TEXT NOT NULL,
    metadata_json TEXT NOT NULL DEFAULT '{}',
    status TEXT NOT NULL DEFAULT 'draft'
);

CREATE TABLE IF NOT EXISTS renderable_variants_v2 (
    id TEXT PRIMARY KEY,
    renderable_item_id TEXT NOT NULL REFERENCES renderable_items_v2(id) ON DELETE CASCADE,
    style_json TEXT NOT NULL DEFAULT '{}',
    status TEXT NOT NULL DEFAULT 'draft'
);

CREATE TABLE IF NOT EXISTS render_profiles_v2 (
    id TEXT PRIMARY KEY,
    render_variant_id TEXT NOT NULL REFERENCES renderable_variants_v2(id) ON DELETE CASCADE,
    avatar_id TEXT,
    pose_id TEXT,
    media_asset_id TEXT REFERENCES media_assets(id) ON DELETE SET NULL,
    render_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS generation_profiles_v2 (
    id TEXT PRIMARY KEY,
    subject_type TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    profile_json TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft'
);

CREATE TABLE IF NOT EXISTS dataset_snapshots_v2 (
    id TEXT PRIMARY KEY,
    version TEXT UNIQUE NOT NULL,
    ruleset_version TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    manifest_json TEXT NOT NULL,
    checksum TEXT NOT NULL,
    published_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS entity_reviews_v2 (
    id TEXT PRIMARY KEY,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    reviewer_id TEXT,
    decision TEXT NOT NULL,
    note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS legacy_item_mappings_v2 (
    legacy_item_id TEXT PRIMARY KEY REFERENCES items(id) ON DELETE CASCADE,
    canonical_entity_type TEXT NOT NULL,
    canonical_entity_id TEXT NOT NULL,
    canonical_variant_id TEXT,
    renderable_item_id TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
