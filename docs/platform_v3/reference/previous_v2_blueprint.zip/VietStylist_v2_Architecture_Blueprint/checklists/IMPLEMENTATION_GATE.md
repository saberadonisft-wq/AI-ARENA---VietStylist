# Implementation Gate

## Trước merge
- [ ] V1 regression pass
- [ ] Fixture validate
- [ ] New schema có version
- [ ] Không hard-code cultural fact vào UI
- [ ] Không destructive migration
- [ ] OpenAPI/type contract được cập nhật nếu API đổi
- [ ] Rights được kiểm trước generation
- [ ] Không external AI call trong unit tests
- [ ] Files changed nằm trong phase
- [ ] Known limitations được ghi

## Trước switch V2 thành mặc định
- [ ] Compose → save → reload
- [ ] Warning + source explanation
- [ ] Old outfit v1 đọc được
- [ ] Generation mock end-to-end
- [ ] Provider failure không làm mất outfit
- [ ] Frontend build/typecheck
- [ ] Backend tests
- [ ] Playwright core flow
