# Data Record Review

## Source
- [ ] title
- [ ] creator/institution nếu biết
- [ ] source type
- [ ] access date
- [ ] URL/bibliographic locator
- [ ] rights capability
- [ ] review status

## Assertion
- [ ] subject tồn tại
- [ ] predicate rõ
- [ ] qualifier thời kỳ/vùng nếu cần
- [ ] evidence locator cụ thể
- [ ] claim thực sự được source hỗ trợ
- [ ] consensus đúng
- [ ] không biến interpretation thành fact

## Generation
- [ ] must_preserve có assertion reviewed
- [ ] media reference có AI rights
- [ ] disputed fact không thành hard constraint
