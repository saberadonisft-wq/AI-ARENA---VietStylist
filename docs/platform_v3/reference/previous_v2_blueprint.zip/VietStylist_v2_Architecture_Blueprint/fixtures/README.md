# Fixtures
Dữ liệu ở đây chỉ để kiểm thử kiến trúc. Không phải cultural facts thật.
APP team dùng fixtures để phát triển độc lập với DATA team.
