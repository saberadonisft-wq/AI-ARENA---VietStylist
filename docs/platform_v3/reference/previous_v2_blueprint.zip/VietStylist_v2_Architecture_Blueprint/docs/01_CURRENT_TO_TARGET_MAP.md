# 01 — Mapping source hiện tại → V2

## Backend hiện tại
Repository đang có các module:
`admin`, `auth`, `catalog`, `color_analysis`, `cultural_rules`, `heritage`,
`lookbooks`, `media`, `outfits`, `recommendations`, `shares`,
`solution_forms`, `try_on`, `weather`.

### Quyết định theo module

| Module | V2 | Xử lý |
|---|---|---|
| catalog | legacy adapter | giữ, không xóa sprint đầu |
| heritage | education projection/editorial | fact quan trọng chuyển về assertions |
| cultural_rules | cultural_validation | condition thành data, engine thành code |
| color_analysis | styling utility | không coi là cultural truth |
| recommendations | optional inspiration | freeze khỏi core flow |
| weather | optional context | freeze |
| outfits | OutfitSpec v2 persistence | đọc được v1 |
| lookbooks | giữ | lưu OutfitSpec + generated image optional |
| media | giữ | thêm binding provenance/rights |
| try_on | generation | thay 503 bằng orchestrator theo phase |
| auth/admin/shares | giữ | chỉ mở rộng khi cần |

## Database legacy
Các bảng hiện tại đáng giữ:
`accounts`, `profiles`, `user_roles`, `occasions`, `media_assets`,
`outfits`, `outfit_versions`, `lookbooks`, `lookbook_entries`,
`share_links`, `ai_jobs`, `ai_usage`, `weather_cache`.

Các bảng cần adapter/migration:
`garment_types`, `items`, `item_variants`, `avatars`, `asset_layers`,
`heritage_sources`, `heritage_articles`, `cultural_rules`.

## Tách khái niệm `items`
Legacy `items` đang trộn:
- cultural concept;
- render asset;
- UI catalog item.

V2 phải tách:

```text
GarmentDefinition
    ↓
GarmentVariantDefinition
    ↓
RenderableItem
    ↓
RenderableVariant
    ↓
RenderProfile (PNG/SVG/mask/anchor/z-index)
```

Ví dụ:
```text
Áo ngũ thân                     ← canonical
Ngũ thân nam/form X             ← canonical variant
item_ngu_than_nam_xanh          ← renderable app item
var_...                         ← renderable variant
PNG + mask                      ← render profile
```

## Heritage
Không tiếp tục mô hình:
`article text = source of truth`.

Mô hình mới:
```text
SourceRecord
   ↓
CulturalAssertion
   ↓
Canonical Domain
   ↓
Education Projection
```

Article chỉ là storytelling/editorial projection.

## Cultural rules
Legacy service đang có nhánh theo code rule. V2:
```text
rule definition = data
rule interpreter = code
```
Không thêm mỗi rule mới bằng `elif garment == ...`.

## Outfit v1 → v2
Legacy snapshot gồm avatar, pose, occasion, style mode, items, locked slots,
background, aspect ratio.

V2:
```text
OutfitSpecV2
├─ schema_version
├─ dataset_version
├─ ruleset_version
├─ selections[]
│  ├─ canonical_entity_id
│  ├─ canonical_variant_id
│  ├─ renderable_item_id
│  ├─ render_variant_id
│  ├─ style
│  └─ transform
├─ context
└─ legacy_render_context
```

Đọc v1 bằng adapter; write mới bằng v2.

## Frontend hiện tại
`frontend/src/app/page.tsx` đang ôm nhiều state/API/business logic.
`frontend/src/features/studio/state.ts` đã có reducer/history nhưng chưa là source of truth duy nhất.

V2:
```text
StudioPage
→ ComposerContainer
   ├─ useComposerBundle
   ├─ useComposerDocument
   ├─ useCulturalValidation
   ├─ useOutfitPersistence
   └─ useGeneration
```

`Canvas2D` chỉ render; không biết cultural facts, save API hay AI prompt.

## Try-on
Không nối provider thẳng vào `try_on/service.py`.
Tạo:
```text
generation/
  orchestrator
  grounding_builder
  reference_selector
  prompt_builder
  post_validator
  providers/
```
Legacy try-on route có thể delegate sang module mới sau.
