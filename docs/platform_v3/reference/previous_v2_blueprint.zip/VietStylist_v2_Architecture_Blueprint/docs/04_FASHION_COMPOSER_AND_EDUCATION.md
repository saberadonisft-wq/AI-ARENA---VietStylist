# 04 — Fashion Composer + Education

## A. Composer

### 1. Người dùng là stylist
Core flow:
```text
chọn base garment
→ chọn variant
→ chọn layer
→ chọn màu/material
→ chọn accessory
→ xem warning
→ lưu OutfitSpec
→ thử trên ảnh
```

AI suggestion nếu có chỉ nằm ở nút phụ “Inspire me”.

### 2. OutfitSpec v2

```text
schema_version
dataset_version
ruleset_version
title
selections[]
context
legacy_render_context
metadata
```

Mỗi selection:
```text
selection_id
slot
canonical_entity_type
canonical_entity_id
canonical_variant_id?
renderable_item_id?
render_variant_id?
style:
  color_hex?
  material_id?
  pattern_id?
transform?
```

### 3. Không hard-code slot toàn app
Dùng composition schema theo garment family.

Ví dụ:
```text
required: base_upper, lower
optional: inner_upper, outer_upper, headwear, handheld
```

Legacy slot map sang registry mới.

### 4. State machine
```text
EMPTY
→ BASE_SELECTED
→ COMPOSING
→ DIRTY
→ VALIDATED
→ SAVED
→ GENERATION_PENDING
```

Warning không chặn save.

### 5. Reducer duy nhất
Actions:
- LOAD_BUNDLE
- LOAD_OUTFIT
- ADD_SELECTION
- REMOVE_SELECTION
- REPLACE_SELECTION
- SET_STYLE_VALUE
- SET_TRANSFORM
- SET_CONTEXT
- SET_LAYER_ORDER
- LOCK/UNLOCK
- APPLY_VALIDATION
- UNDO/REDO
- RESET
- MARK_SAVED

Reducer không gọi API.

### 6. Fast vs authoritative validation
Client:
- duplicate slot
- unsupported choice
- simple compatibility

Server:
- dataset current version
- full rules
- source-backed validation

Nếu bundle stale:
- server trả `BUNDLE_STALE`
- frontend refresh bundle rồi validate lại.

### 7. Canvas2D
Canvas chỉ render `RenderDocument`.
Không:
- fetch API
- save
- cultural check
- build prompt
- quyết định outfit

Nếu thiếu PNG:
- placeholder card/silhouette.
Không block user.

### 8. Cultural panel
Không chỉ badge ✓.

Nên có:
```text
Cấu trúc      1 notice
Phụ kiện      1 warning
Bối cảnh      clear
Nguồn         3 citations
```

Mỗi issue có:
- why
- source
- suggested alternative
- “giữ lựa chọn của tôi”

### 9. Color
Color analysis là styling utility.
Không kết luận tuyệt đối đẹp/xấu.
Có thể ghi:
- analogous
- contrast
- documented palette
- modern adaptation

---

## B. Education

### 1. Không có knowledge database thứ hai
Education là projection từ Cultural Data Core.

### 2. Garment detail projection
```text
identity
summary
timeline/context
components
wearing structure
documented styles
modern adaptation
media gallery
source citations
uncertainty notes
related entities
CTA mở Composer
```

### 3. Học khi đang phối
Trong Composer:
- click item → xem cultural note
- click warning → xem evidence
- click source → mở citation
- click component → mở detail

### 4. Uncertainty UX
Nếu disputed:
> Các nguồn hiện có mô tả khác nhau ở chi tiết này.

Không nói:
> Đây là cách duy nhất đúng.

### 5. Cache
Cache theo:
```text
dataset_version + garment_id + locale
```
Publish snapshot mới → cache key mới.
