# 08 — Testing, Governance, Risks

## Testing pyramid

### Schema/fixture
Fail nếu:
- duplicate ID
- dangling reference
- unknown vocabulary
- assertion không evidence
- hard rule dùng disputed assertion
- generation ref không có rights
- render item không map canonical
- invalid operator

### Domain
- rule evaluator
- OutfitSpec migration
- grounding builder
- reference selector
- rights filter

### API
- published vs draft
- bundle
- validation
- generation lifecycle
- auth/ownership

### E2E
- compose
- warning
- save/reload
- mock generation
- lookbook

## Rule golden tests
Mỗi rule có:
- positive
- negative
- edge

Không có rule production mà không có test case.

## Grounding deterministic
Cùng:
- OutfitSpec
- dataset version
- profile versions

→ canonical grounding hash giống nhau.

## Rights tests
`may_use_for_ai_reference=false`
→ asset tuyệt đối không đi vào ProviderRequest.

## DATA workflow
```text
discover source
→ register source
→ assess rights
→ extract assertion
→ attach locator
→ review
→ canonical mapping
→ publish
```

## Roles
- Researcher: nhập source/assertion.
- Reviewer: kiểm claim/evidence.
- Publisher: tạo snapshot.

Hackathon có thể kiêm người, nhưng state workflow vẫn tách.

## Risk register

### Dataset nhỏ
Giải pháp: depth > breadth; pilot 2–5 garment.

### AI sinh sai
Grounding + reference + post-validation + limitation UX.

### 2D asset thiếu
Canonical/render tách nhau; fallback placeholder.

### Copyright/rights
Capability-based rights, default deny.

### Refactor vỡ demo
Parallel V2 + regression.

### Rule engine nguy hiểm
No eval; whitelist; depth limit.

### AI coding agent sửa quá rộng
Phase prompt + test gate + stop condition.

### Frontend state tiếp tục phình
One reducer + feature hooks + page-only composition.
