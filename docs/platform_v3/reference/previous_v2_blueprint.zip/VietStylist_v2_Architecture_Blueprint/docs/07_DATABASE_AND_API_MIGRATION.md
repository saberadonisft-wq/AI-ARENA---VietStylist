# 07 — Database + API Migration

## 1. Chiến lược
Strangler / parallel schema.

Không:
- drop table
- rename destructive
- rewrite all rows
trong sprint đầu.

## 2. New V2 tables
- cultural_sources_v2
- cultural_assertions_v2
- assertion_evidence_v2
- garment_definitions_v2
- garment_variants_v2
- garment_components_v2
- accessory_definitions_v2
- style_options_v2
- compatibility_relations_v2
- cultural_rules_v2
- cultural_media_bindings_v2
- renderable_items_v2
- renderable_variants_v2
- render_profiles_v2
- generation_profiles_v2
- dataset_snapshots_v2
- entity_reviews_v2
- legacy_item_mappings_v2

## 3. Reuse legacy tables
- media_assets
- outfits
- outfit_versions
- lookbooks
- lookbook_entries
- ai_jobs
- ai_usage

## 4. Legacy mapping
`items` không bị xóa. Dùng mapping:
```text
legacy_item_id
canonical_entity_type
canonical_entity_id
canonical_variant_id
renderable_item_id
```

## 5. Heritage migration
`heritage_sources` → `cultural_sources_v2` có thể migrate metadata.

Không tự động biến toàn bộ paragraph article thành assertion vì đó là bước nghiên cứu/review.

## 6. Rule migration
Dual run:
1. legacy rule service.
2. v2 rule engine.
3. golden fixtures.
4. so output.
5. chỉ switch khi behavior chấp nhận được.

## 7. Outfit migration
Read:
```text
schemaVersion 1 → adapt in memory → OutfitSpecV2
schemaVersion 2 → parse direct
```

Write mới:
```text
schemaVersion = 2
```

Không batch rewrite toàn bộ trước deadline.

## 8. API V2

### Public cultural
- GET /api/v2/cultural/garments
- GET /api/v2/cultural/garments/{id_or_slug}
- GET /api/v2/cultural/sources/{id}
- GET /api/v2/cultural/assertions/{id}

### Composer
- GET /api/v2/composer/bundles/{garment_id}
- POST /api/v2/composer/validate

### Outfits
- POST /api/v2/outfits
- GET /api/v2/outfits/{id}
- PUT /api/v2/outfits/{id}
- GET /api/v2/outfits/{id}/versions

### Generation
- POST /api/v2/generations
- GET /api/v2/generations/{job_id}
- POST /api/v2/generations/{job_id}/retry

### Admin
- CRUD source/assertion/garment/rule
- POST /api/v2/admin/cultural/datasets/publish

## 9. Stale bundle handling
Composer request mang:
- dataset_version
- ruleset_version

Server mismatch:
- HTTP 409
- code `BUNDLE_STALE`
- frontend reload bundle rồi revalidate.

## 10. OpenAPI
Mỗi contract change:
- export OpenAPI
- update shared/openapi.json
- typecheck frontend
- contract test

Không maintain Python/TS/schema lệch nhau mà không test.
