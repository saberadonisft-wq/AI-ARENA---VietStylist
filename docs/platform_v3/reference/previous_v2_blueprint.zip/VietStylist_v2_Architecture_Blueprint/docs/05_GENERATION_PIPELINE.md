# 05 — Generation / Try-On Pipeline

## 1. AI không chọn outfit
Input từ user:
```text
UserImageRef + OutfitSpec + GenerationOptions
```

Backend enrich thành:
```text
GroundingPackage
```

## 2. GenerationProfile

Mỗi garment/variant cần:
- identity
- must_preserve
- may_vary
- forbidden
- reference_media_binding_ids

`must_preserve` chỉ lấy từ assertion đủ điều kiện review.

## 3. GroundingBuilder

Algorithm:
1. Parse OutfitSpec.
2. Validate canonical IDs.
3. Check dataset/ruleset version.
4. Resolve variants/components/accessories.
5. Load GenerationProfiles.
6. Collect must_preserve.
7. Collect user colors/materials.
8. Select rights-eligible references.
9. Remove disputed/low-confidence hard constraints.
10. Canonicalize + hash GroundingPackage.

## 4. ReferenceSelector
Không gửi 30–50 ảnh.

Ưu tiên:
- 1–2 front/full
- 1 back nếu cần
- 1–3 detail cho feature bắt buộc
- selected accessory refs

Ranking:
1. rights eligible
2. reviewed
3. exact variant
4. visibility cao
5. view diversity

## 5. PromptBuilder
Prompt không hard-code knowledge trong provider client.

Template sections:
- task
- user identity preservation
- selected outfit
- mandatory features
- selected colors/materials
- allowed variation
- forbidden changes
- reference mapping

## 6. Provider abstraction

```python
class GenerationProvider:
    async def generate(request) -> result:
        ...
```

ProviderRequest:
- user image
- references
- prompt
- output options
- idempotency key

ProviderResult:
- provider job id
- model id
- result media
- latency
- status metadata

Domain không biết field vendor.

## 7. Job states
- queued
- preparing
- provider_submitted
- provider_processing
- post_validating
- completed
- completed_with_warning
- failed_retryable
- failed_terminal
- cancelled

## 8. Idempotency hash
Hash:
```text
user_image_hash
+ canonical OutfitSpec
+ dataset_version
+ profile versions
+ provider/model
+ options
```

## 9. Post-validation
MVP kiểm:
- selected major items có hiện diện không
- feature must-preserve có bị mất/đảo không
- màu lệch lớn không
- accessory hallucination không
- identity bị thay mạnh không nếu tool hỗ trợ

Result:
- PASS
- PASS_WITH_LIMITATIONS
- NEEDS_REVIEW
- FAIL_REGENERATE

Không claim “100% culturally accurate”.

## 10. Retry
- bounded retry
- corrective prompt
- không loop vô hạn
- lưu trace

## 11. User photo privacy
Khuyến nghị:
- private by default
- raw user photo tách storage prefix/bucket
- retention ngắn theo policy
- generated result giữ theo user choice
- không dùng ảnh user làm training data mặc định
- không gửi provider trước khi UI có consent phù hợp

## 12. Audit record
Mỗi generation lưu:
- outfit_version_id
- dataset_version
- ruleset_version
- generation_profile_versions
- prompt_template_version
- provider/model
- reference media IDs
- grounding hash
- result media id
- post validator version/result

Debug sai văn hóa dựa trên trace này.
