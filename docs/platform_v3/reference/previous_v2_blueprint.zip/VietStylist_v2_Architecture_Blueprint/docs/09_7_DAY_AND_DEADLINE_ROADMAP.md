# 09 — 7 ngày + roadmap đến 09/10/2026

## 18/09 — Contract
DATA:
- vocab
- source schema
- assertion schema
- rights
- pilot records

APP:
- Pydantic/TS contracts
- JSON schema
- fixture validator
- tests

Gate:
- fake dataset parse
- invalid fixture fail

## 19/09 — Repository + Read API
DATA:
- 3 source mẫu
- conflicting assertion case
- restricted media case

APP:
- v2 repository
- garment list/detail
- source/assertion read
- frontend API client

Gate:
- đổi fixture → UI đổi

## 20/09 — ComposerBundle
DATA:
- components
- accessories
- style options
- fake render mapping

APP:
- bundle service
- endpoint
- picker panels

Gate:
- user compose được semantic outfit

## 21/09 — OutfitSpec + State
BACKEND:
- OutfitSpec v2
- v1 adapter
- persistence

FRONTEND:
- reducer source of truth
- undo/redo
- local draft
- Canvas adapter

Gate:
- compose/save/reload đúng

## 22/09 — Rule Engine
DATA:
- 3–6 rules có evidence

APP:
- safe interpreter
- validate endpoint
- cultural panel
- source drawer

Gate:
- warning theo selection
- không hard-code new garment-specific elif

## 23/09 — Generation Mock
DATA:
- 1 GenerationProfile
- reference mapping

APP:
- GroundingBuilder
- rights filter
- prompt builder
- mock provider
- generation job UI

Gate:
- OutfitSpec → mock generated result

## 24/09 — Freeze
- backend tests
- frontend typecheck/build
- E2E
- OpenAPI
- docs
- setup runbook
- schema candidate freeze

---

## 25–28/09
Đổ 2–3 garment dữ liệu thật sâu.
Composer dùng data thật.
Review rights/rules.

## 29/09–02/10
Nối provider tạo ảnh thật.
Chọn 1–2 golden demo cases.
Post-validation cơ bản.

## 03–05/10
Polish:
- education
- composer UX
- lookbook
- responsive
- performance
- error states

## 06–07/10
Hardening:
- clean machine
- slow network
- provider fail
- invalid image
- stale bundle
- missing assets
- retry
- permission

## 08/10
Freeze code.
Chỉ fix blocker.

## 09/10
Submission + deployment verification.
