# 03 — Cultural Data Core

## 1. Phân tầng dữ liệu

### Evidence Layer
- `SourceRecord`
- `MediaAssetBinding`
- `CulturalAssertion`
- `AssertionEvidence`
- `RightsProfile`
- `ReviewRecord`

### Canonical Domain Layer
- `GarmentDefinition`
- `GarmentVariantDefinition`
- `GarmentComponentDefinition`
- `AccessoryDefinition`
- `StyleOption`
- `CompatibilityRelation`
- `CulturalRule`

### App Render Layer
- `RenderableItem`
- `RenderableVariant`
- `RenderProfile`
- `ColorMaskProfile`

### User Layer
- `OutfitSpec`
- `OutfitVersion`
- `ValidationResult`
- `LookbookEntry`

### AI Layer
- `GenerationProfile`
- `GenerationRequest`
- `GroundingPackage`
- `GenerationJob`
- `GenerationResult`
- `PostValidationResult`

---

## 2. SourceRecord

Nguồn không phải chỉ là URL. Mỗi nguồn phải có:
- loại nguồn;
- tác giả / tổ chức;
- title;
- publication date nếu có;
- accessed date;
- language;
- rights;
- trust tier;
- review status.

`source_type`:
- museum_record
- archival_record
- academic_paper
- academic_book
- specialist_book
- official_institution_web
- expert_interview
- historical_image
- community_documentation
- commercial_reference
- other

`trust_tier` là tín hiệu workflow, không phải xác suất chân lý:
- A_PRIMARY
- B_SCHOLARLY
- C_INSTITUTIONAL
- D_EXPERT_CURATED
- E_CONTEXTUAL
- F_UNVERIFIED

---

## 3. RightsProfile

Không dùng một field `license_note` duy nhất.

```text
may_store
may_display_publicly
may_transform
may_crop
may_use_for_ai_reference
may_export
attribution_required
license
rights_note
```

Policy:
- unknown → default deny public/AI.
- education display và AI reference là hai quyền khác nhau.
- app phải filter media trước khi gửi provider.

---

## 4. MediaAssetBinding

`media_assets` hiện tại vẫn là physical storage.
V2 thêm semantic binding:

```text
media_asset_id
source_id
subject_type
subject_id
view_type
quality
usage
```

`view_type`:
- front
- back
- left
- right
- three_quarter
- full_body
- collar_detail
- closure_detail
- sleeve_detail
- hem_detail
- fabric_detail
- pattern_detail
- accessory_detail
- construction_diagram
- historical_context
- museum_display
- modern_reconstruction

Một ảnh có thể bind tới garment và component cùng lúc bằng nhiều binding record.

---

## 5. CulturalAssertion

Assertion là đơn vị tri thức có provenance.

Ví dụ:
```text
subject = garment_variant:X
predicate = closure.direction
value = right_over_left
qualifier.period = ...
```

Fields:
- id
- subject(type,id)
- predicate
- value
- qualifiers
- statement_vi
- evidence[]
- confidence
- consensus
- review_status
- version

`consensus`:
- single_source
- corroborated
- strong_consensus
- mixed
- disputed
- uncertain

Rule:
- hard generation constraint chỉ lấy assertion đã review và đủ mạnh.
- disputed assertion không thành hard rule.
- styling heuristic không giả dạng assertion lịch sử.

---

## 6. GarmentDefinition và Variant

### GarmentDefinition
Khái niệm canonical tổng quát.

### GarmentVariantDefinition
Biến thể có ý nghĩa cấu trúc/thời kỳ/vùng/nghi lễ.
Không tạo variant chỉ vì khác màu.

---

## 7. GarmentComponentDefinition

Component semantic:
- collar
- sleeve
- closure
- front_panel
- back_panel
- inner_panel
- outer_panel
- waist
- hem
- fastener
- lining

Mỗi component có:
```text
structural_role = mandatory | optional | conditional
generation_policy:
  preserve_presence
  preserve_shape
  allow_color_change
  allow_material_change
  forbid_removal
```

---

## 8. AccessoryDefinition

Accessory độc lập khỏi garment.

Có:
- category
- compatible relations
- assertions
- media
- generation policy
- render mappings

---

## 9. StyleOption

Các trạng thái:
- documented
- historically_plausible
- modern_adaptation
- experimental

Mục tiêu: phân biệt “đã ghi nhận” với “remix hiện đại”.

---

## 10. CompatibilityRelation

Model:
```text
subject
relation
object
qualifiers
assertion_ids
status
```

Relations:
- requires
- recommended_with
- compatible_with
- conditionally_compatible
- historically_attested_with
- modern_pairing
- discouraged_with
- layer_before
- layer_after

---

## 11. CulturalRule

Rule là data, engine là code.

Categories:
- STRUCTURAL
- LAYERING
- ACCESSORY
- OCCASION
- HISTORICAL_CONTEXT
- GENERATION_GUARDRAIL
- STYLING_HEURISTIC

Severity:
- info
- notice
- warning
- strong_warning

Cultural rule không block user trừ lỗi kỹ thuật/security/rights.

---

## 12. RenderableItem

Đây là lớp giải quyết bài toán 2D.

Canonical knowledge không phụ thuộc PNG.

`RenderableItem` chứa:
- canonical entity id
- canonical variant id
- slot
- supported avatar/pose
- render variants
- z-order
- mask capability

Nếu chưa có asset 2D:
- user vẫn có thể compose semantic item;
- preview dùng placeholder/silhouette;
- generation vẫn dùng canonical data.

---

## 13. ComposerBundle

Frontend không fetch 10 endpoint cho một lần phối.

Bundle:
```text
dataset_version
ruleset_version
garment
variants
renderable_items
accessories
style_options
rules
short_explanations
```

Bundle là read model, không phải DB dump.

---

## 14. Publication snapshot

Public app chỉ đọc published snapshot.

```text
draft records
→ review
→ publish
→ DatasetSnapshot
```

Snapshot lưu:
- version
- ruleset_version
- manifest
- checksum
- published_at
- entity version map
