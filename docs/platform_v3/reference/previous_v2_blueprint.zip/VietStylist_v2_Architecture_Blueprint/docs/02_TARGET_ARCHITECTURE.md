# 02 — Target Architecture

## Product model
Ba trải nghiệm, một core:

```text
CULTURAL DATA CORE
├─ Education
├─ Composer
└─ Generation
```

### Education trả lời
- Đây là gì?
- Cấu tạo nào được nguồn hỗ trợ?
- Nguồn nào?
- Phần nào còn tranh luận?
- Phần nào là adaptation hiện đại?

### Composer trả lời
- User muốn mặc/phối cái gì?
- Các item có thể cùng tồn tại không?
- Layer, màu, phụ kiện ra sao?
- Có cảnh báo văn hóa nào?
- Không tự đổi quyết định của user.

### Generation trả lời
- Làm sao render chính OutfitSpec đó lên ảnh user?
- Chi tiết nào bắt buộc giữ?
- Reference nào hợp lệ?
- Sau generation có dấu hiệu sai gì?

## Bounded contexts

### cultural_data
Sở hữu:
- sources
- rights
- assertions
- canonical garments/variants/components/accessories
- publication snapshot

Không biết:
- Gemini
- canvas
- user photo

### composer
Sở hữu:
- ComposerBundle
- OutfitSpec
- composition compatibility
- render mapping

Không biết:
- raw source document
- provider-specific API

### cultural_validation
Sở hữu:
- rule interpreter
- ValidationResult
- explainability references

Không mutate outfit.

### generation
Sở hữu:
- GenerationProfile
- GroundingPackage
- provider orchestration
- generation jobs
- post-validation

Không chọn outfit thay user.

### education
Read projection của cultural_data.

## Dependency rules

Allowed:
```text
education → cultural_data
composer → cultural_data
validation → cultural_data
generation → cultural_data
generation → composer
generation → validation
lookbook → outfits/composer
```

Forbidden:
```text
cultural_data -X→ provider
composer -X→ Gemini client
Canvas2D -X→ database
rule engine -X→ React
provider -X→ canonical DB repository trực tiếp
```

## 4 loại thông tin phải phân biệt
1. Cultural/historical fact.
2. Curatorial interpretation.
3. Styling heuristic.
4. User creative choice.

Không được trình bày 3 hoặc 4 như fact lịch sử.

## Version boundaries
Mọi output quan trọng phải truy được:
- dataset_version
- garment_definition_version
- ruleset_version
- outfit_spec_schema_version
- generation_profile_version
- prompt_template_version
- provider/model_version
- post_validator_version

## Read model
Không trả graph thô cho frontend. Dùng:
- GarmentCard
- GarmentEducationDetail
- ComposerBundle
- RuleExplanation
- SourceCitation
- GenerationStatus

Điều này cho phép DB đổi mà frontend ít đổi.
