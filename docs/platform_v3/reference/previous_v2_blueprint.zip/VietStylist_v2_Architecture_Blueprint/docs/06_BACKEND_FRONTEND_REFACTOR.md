# 06 — Backend + Frontend Refactor

## A. Backend target

### Module tree
```text
backend/app/modules/
├── cultural_data/
│   ├── domain/
│   │   ├── enums.py
│   │   ├── source.py
│   │   ├── assertion.py
│   │   ├── garment.py
│   │   ├── accessory.py
│   │   ├── style.py
│   │   ├── rule.py
│   │   └── generation_profile.py
│   ├── schemas/
│   ├── repositories/
│   ├── services/
│   └── routes/
├── composer_v2/
│   ├── domain/
│   ├── services/
│   ├── repository.py
│   └── router.py
├── cultural_validation/
│   ├── interpreter/
│   ├── rule_engine.py
│   ├── service.py
│   └── router.py
└── generation/
    ├── domain/
    ├── providers/
    ├── services/
    ├── repository.py
    └── router.py
```

### Router
Không rewrite `main.py`. Chỉ add router v2:
```text
/api/v2/...
```
V1 tiếp tục `/api/...`.

### Repositories
Service không raw SQL rải rác.
Tối thiểu:
- SourceRepository
- AssertionRepository
- GarmentRepository
- RenderCatalogRepository
- OutfitRepository
- GenerationRepository

SQLite implementation hiện tại, Postgres implementation sau.

### Rule engine
Whitelist operators:
- eq / neq
- in / not_in
- contains / not_contains
- exists / missing
- gt / gte / lt / lte
- all / any

Không `eval`.
Whitelist field paths.
Giới hạn nesting/depth.

### Media
Reuse `media_assets`.
Thêm `cultural_media_bindings_v2` để chứa:
- provenance
- semantic subject
- view type
- usage
- rights

### AI jobs
Reuse `ai_jobs`.
Task type mới: `outfit_generation_v2`.

### Error codes
- DATASET_VERSION_NOT_FOUND
- ENTITY_NOT_FOUND
- ENTITY_NOT_PUBLISHED
- BUNDLE_STALE
- OUTFIT_SCHEMA_UNSUPPORTED
- OUTFIT_INVALID_REFERENCE
- RULESET_VERSION_NOT_FOUND
- GENERATION_NOT_READY
- GENERATION_PROVIDER_ERROR
- GENERATION_REFERENCE_FORBIDDEN
- MEDIA_RIGHTS_RESTRICTION

---

## B. Frontend target

### Feature tree
```text
frontend/src/features/
├── cultural-data/
├── education/
├── composer/
│   ├── api/
│   ├── components/
│   ├── hooks/
│   ├── rendering/
│   └── state/
├── generation/
└── cultural-validation/
```

### Refactor `app/page.tsx`
Page chỉ layout:
```text
StudioPage → ComposerContainer
```

ComposerContainer dùng:
- useComposerBundle
- useComposerDocument
- useComposerValidation
- useOutfitPersistence
- useGeneration

### Refactor `features/studio/state.ts`
Tách:
- reducer.ts
- history.ts
- selectors.ts
- migrations.ts
- types.ts

Đây phải là source of truth duy nhất.

### Canvas2D target props
```ts
type Props = {
  renderDocument: RenderDocument;
  selectedId?: string;
  onSelect?: (id: string) => void;
  onTransform?: (...) => void;
}
```

Canvas không gọi API.

### Draft v2
Key mới:
`viet_stylist_composer_draft_v2`

Nếu v1 có:
- migrate một lần;
- không xóa im lặng.

### Generation UI
`AITryOnModal` chỉ:
- upload/select image
- show OutfitSpec summary
- consent
- create generation job
- poll job
- show result + limitation

Không build prompt ở frontend.

### Loading states riêng
- bundle_loading
- validation_loading
- save_loading
- upload_loading
- generation_queue
- generation_processing
- generation_validating

### E2E critical
```text
open
→ select garment
→ add accessory
→ change color
→ warning appears
→ undo/redo
→ save
→ reload
→ restore
→ mock generation
→ result
```
