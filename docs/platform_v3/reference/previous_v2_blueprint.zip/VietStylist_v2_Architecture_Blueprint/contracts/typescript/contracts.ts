export type ReviewStatus =
  | "draft" | "under_review" | "verified" | "published"
  | "disputed" | "deprecated" | "rejected";

export interface RightsProfile {
  may_store: boolean;
  may_display_publicly: boolean;
  may_transform: boolean;
  may_crop?: boolean;
  may_use_for_ai_reference: boolean;
  may_export?: boolean;
  attribution_required: boolean;
  license?: string | null;
  rights_note?: string | null;
}

export interface CulturalAssertion {
  id: string;
  subject: { type: string; id: string };
  predicate: string;
  value: unknown;
  qualifiers?: Record<string, unknown>;
  statement_vi: string;
  evidence: Array<{ source_id: string; locator: string; media_binding_ids?: string[] }>;
  confidence: number;
  consensus: string;
  review_status: ReviewStatus;
  version: number;
}

export interface OutfitSelection {
  selection_id: string;
  slot: string;
  canonical_entity_type: "garment" | "garment_variant" | "accessory" | "component";
  canonical_entity_id: string;
  canonical_variant_id?: string | null;
  renderable_item_id?: string | null;
  render_variant_id?: string | null;
  style: Record<string, unknown>;
  transform?: { dx: number; dy: number; scale: number; rotation: number } | null;
}

export interface OutfitSpecV2 {
  schema_version: "2.0";
  dataset_version: string;
  ruleset_version?: string | null;
  title?: string;
  selections: OutfitSelection[];
  context: {
    occasion_id?: string | null;
    style_intent?: string | null;
    mode: "traditional" | "remix" | "modern_fusion";
    [key: string]: unknown;
  };
  legacy_render_context?: Record<string, unknown> | null;
  metadata?: Record<string, unknown>;
}

export interface ValidationIssue {
  rule_id: string;
  severity: "info" | "notice" | "warning" | "strong_warning";
  title_vi?: string;
  message_vi: string;
  assertion_ids?: string[];
  source_ids?: string[];
}
