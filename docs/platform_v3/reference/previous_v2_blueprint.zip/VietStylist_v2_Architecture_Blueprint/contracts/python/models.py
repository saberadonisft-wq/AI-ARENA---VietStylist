from __future__ import annotations
from typing import Any, Literal
from pydantic import BaseModel, Field, model_validator

ReviewStatus = Literal["draft","under_review","verified","published","disputed","deprecated","rejected"]

class RightsProfile(BaseModel):
    may_store: bool
    may_display_publicly: bool
    may_transform: bool
    may_crop: bool = False
    may_use_for_ai_reference: bool
    may_export: bool = False
    attribution_required: bool
    license: str | None = None
    rights_note: str | None = None

class EvidenceRef(BaseModel):
    source_id: str
    locator: str
    media_binding_ids: list[str] = Field(default_factory=list)

class CulturalAssertion(BaseModel):
    id: str
    subject: dict[str, str]
    predicate: str
    value: Any
    qualifiers: dict[str, Any] = Field(default_factory=dict)
    statement_vi: str
    evidence: list[EvidenceRef]
    confidence: float = Field(ge=0, le=1)
    consensus: Literal["single_source","corroborated","strong_consensus","mixed","disputed","uncertain"]
    review_status: ReviewStatus
    version: int = Field(default=1, ge=1)

class OutfitTransform(BaseModel):
    dx: float = 0
    dy: float = 0
    scale: float = Field(default=1, gt=0)
    rotation: float = 0

class OutfitSelection(BaseModel):
    selection_id: str
    slot: str
    canonical_entity_type: Literal["garment","garment_variant","accessory","component"]
    canonical_entity_id: str
    canonical_variant_id: str | None = None
    renderable_item_id: str | None = None
    render_variant_id: str | None = None
    style: dict[str, Any] = Field(default_factory=dict)
    transform: OutfitTransform | None = None

class OutfitSpecV2(BaseModel):
    schema_version: Literal["2.0"] = "2.0"
    dataset_version: str
    ruleset_version: str | None = None
    title: str = "Bản phối mới"
    selections: list[OutfitSelection] = Field(default_factory=list)
    context: dict[str, Any] = Field(default_factory=dict)
    legacy_render_context: dict[str, Any] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def unique_selection_ids(self):
        ids = [x.selection_id for x in self.selections]
        if len(ids) != len(set(ids)):
            raise ValueError("selection_id must be unique")
        return self
