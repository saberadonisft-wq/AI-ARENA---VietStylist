# VietStylist v2 — Architecture Blueprint

## Mục tiêu
Biến VietStylist từ một web có nhiều feature rời rạc thành một nền tảng có một lõi dữ liệu văn hóa duy nhất, nơi:
- Người dùng tự phối đồ.
- Cultural Data Core là source of truth.
- Education, Composer và AI Generation dùng chung dữ liệu.
- AI chỉ hỗ trợ giải thích, kiểm tra và render ảnh; không tự quyết định outfit và không tự bịa cultural fact.
- Mọi fact quan trọng đều truy về nguồn/evidence.
- Canonical cultural data tách khỏi asset 2D để app không bị khóa vào một bộ PNG cụ thể.

## Kiến trúc 5 lớp

```text
1. EVIDENCE
   SourceRecord • MediaAsset • CulturalAssertion • Rights • Review
                           ↓
2. CANONICAL CULTURAL DOMAIN
   GarmentDefinition • GarmentVariant • Component • Accessory • Rule
                           ↓
3. APP/RENDER CATALOG
   RenderableItem • RenderableVariant • RenderProfile • StyleOption
                           ↓
4. USER COMPOSITION
   OutfitSpec • ValidationResult • OutfitVersion • Lookbook
                           ↓
5. GENERATION
   GenerationProfile • GroundingPackage • Job • PostValidation
```

## Các quyết định phải khóa
1. Không rewrite project.
2. V1 chạy song song với V2 trong giai đoạn chuyển đổi.
3. Data team và App team giao tiếp bằng schema + fixtures, không bằng chat/Word rời.
4. `OutfitSpec v2` là contract trung tâm.
5. `GarmentDefinition` không phải asset.
6. `RenderableItem` không phải cultural truth.
7. Một generation phải lưu dataset/ruleset/profile/prompt/model version.
8. Unknown rights = không dùng public/AI reference cho tới khi review.
9. Cultural warning không tự động thay lựa chọn của người dùng.
10. Không chuyển DB lớn, làm 3D, AR hoặc train model riêng trước deadline.

## Flow mục tiêu

```text
Nguồn → Assertion → Canonical Garment
                     ├─→ Education
                     ├─→ ComposerBundle → OutfitSpec → Validation
                     └─→ GenerationProfile ───────────┐
                                                    ↓
User Image + OutfitSpec → GroundingPackage → AI Provider
                                      ↓
                               PostValidation
                                      ↓
                                  Lookbook
```

## Sprint architecture đạt khi
Một fixture giả có thể đi được:

```text
fixture
→ schema validator
→ backend repository
→ API v2
→ education projection
→ composer bundle
→ outfit spec
→ rule engine
→ save/reload
→ generation request
→ grounding package
→ mock provider
```

Không cần dataset thật để chứng minh kiến trúc.
