# Phase 5 — Generation mock
Làm:
- GenerationProfile
- GroundingBuilder
- ReferenceSelector + rights filter
- PromptBuilder
- Provider protocol
- Mock provider
- job lifecycle
- generation UI

Không nối external provider.
