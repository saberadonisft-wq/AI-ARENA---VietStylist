# Phase 3 — Composer
Làm:
- OutfitSpec V2
- V1 adapter
- ComposerBundle endpoint
- frontend feature state
- một reducer
- Canvas2D adapter
- save/reload
- undo/redo

Không nối AI provider thật.
