# Phase 6 — External Provider
Chỉ bắt đầu khi mock flow pass.

Yêu cầu:
- credentials từ env
- provider adapter duy nhất
- timeout/retry bounded
- domain không phụ thuộc vendor
- lưu versions/hashes
- post-validation limitation UX
- OutfitSpec không bị provider tự sửa
