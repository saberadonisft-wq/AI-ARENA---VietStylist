# Phase 4 — Cultural Validation
Làm:
- safe rule interpreter
- data-driven rules
- validate endpoint
- CulturalPanel
- source explanation
- golden tests

Không tự replace lựa chọn của user.
