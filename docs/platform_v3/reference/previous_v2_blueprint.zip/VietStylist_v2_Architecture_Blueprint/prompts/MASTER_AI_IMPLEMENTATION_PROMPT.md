# MASTER PROMPT CHO AI CODING AGENT

Bạn đang làm trên repository VietStylist hiện tại.

## Bắt buộc đọc
- 00_START_HERE.md
- docs/01_CURRENT_TO_TARGET_MAP.md
- docs/02_TARGET_ARCHITECTURE.md
- docs/03_CULTURAL_DATA_CORE.md
- docs/04_FASHION_COMPOSER_AND_EDUCATION.md
- docs/05_GENERATION_PIPELINE.md
- docs/06_BACKEND_FRONTEND_REFACTOR.md
- docs/07_DATABASE_AND_API_MIGRATION.md
- docs/08_TESTING_GOVERNANCE_AND_RISKS.md
- docs/09_7_DAY_AND_DEADLINE_ROADMAP.md

## Trước khi sửa code, đọc source hiện tại
- backend/app/main.py
- backend/app/core/database.py
- backend/app/core/migrations.py
- backend/app/modules/catalog/
- backend/app/modules/cultural_rules/
- backend/app/modules/outfits/
- backend/app/modules/media/
- backend/app/modules/try_on/
- frontend/src/app/page.tsx
- frontend/src/features/studio/state.ts
- frontend/src/features/studio/Canvas2D.tsx
- frontend/src/lib/api/client.ts
- frontend/src/lib/types/api.ts
- shared/openapi.json

## Luật triển khai
1. Không rewrite project.
2. Không xóa/đổi destructive schema legacy trong sprint đầu.
3. V1 phải còn chạy.
4. User là tác giả OutfitSpec.
5. AI không tự bịa cultural facts.
6. Canonical cultural data tách khỏi render assets.
7. Source/evidence/rights phải truy vết.
8. Rule mới phải data-driven nếu biểu diễn được bằng rule engine.
9. Không sửa file ngoài phase nếu không cần.
10. Không bypass test.
11. Không gửi media cho provider khi quyền AI-reference không cho phép.
12. Không gọi external AI trong unit test.
13. Không hard-code cultural facts trong React.

## Trước mỗi phase
Báo:
- current state
- exact files to add/modify
- migration impact
- risks
- tests to run

Sau đó chỉ làm phase được giao.

## Kết quả bắt buộc cuối phase
- Summary
- Files added
- Files modified
- Migration files
- API changes
- Tests executed
- Test results
- Known limitations
- Next phase prerequisites

DỪNG. Không tự sang phase tiếp.
