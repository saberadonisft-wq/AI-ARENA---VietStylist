# Phase 2 — Read API
Làm:
- V2 repositories
- fixture/SQLite implementation
- garment list/detail
- source/assertion read
- ComposerBundle skeleton
- API tests

Không đổi behavior catalog V1.
