# Phase 1 — Contracts only
Làm:
- Pydantic V2 contracts
- JSON schemas
- controlled enums
- fixtures
- reference validator
- unit tests

Không:
- UI
- provider
- refactor page
- destructive migration

Gate:
- fixture hợp lệ pass
- dangling refs fail
- rights invalid fail
- legacy tests không regress
